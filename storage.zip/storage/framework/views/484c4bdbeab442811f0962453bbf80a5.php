
<?php $__env->startSection('title', __('messages.transaction_list')); ?>
<?php $__env->startSection('content'); ?>

  <section class="pc-container">
    <div class="pc-content">
        <div class="page-header">
          <div class="page-block">
            <div class="row align-items-center">
              <div class="col-md-12">
                <ul class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('messages.dashboard')); ?></a></li>
                  <li class="breadcrumb-item" aria-current="page"><?php echo e(__('messages.leads')); ?></li>
                </ul>
              </div>
              <div class="col-md-12">
                <div class="page-header-title">
                  <h2 class="mb-0"><?php echo e(__('messages.transaction_list')); ?></h2>
                </div>
              </div>
            </div>
          </div>
        </div>

      <div class="row">
        <div class="col-sm-12">
          <div class="card">
            <div class="card-body">
              <div class="dt-responsive table-responsive">
                <table id="base-style" class="table table-striped table-bordered nowrap">
                  <thead>
                    <tr>
                        <th><?php echo e(__('messages.job_type')); ?></th>
                        <th><?php echo e(__('messages.services')); ?></th>
                        <th><?php echo e(__('messages.budget')); ?></th>
                        <th><?php echo e(__('messages.name')); ?></th>
                        <th><?php echo e(__('messages.purchase_date')); ?></th>
                        <?php if(Auth::user()->type === 0): ?>
                          <th><?php echo e(__('messages.purchased_by')); ?></th>
                        <?php endif; ?>
                        <th><?php echo e(__('messages.actions')); ?></th>
                    </tr>
                  </thead>
                  <tbody></tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(function () {
            var columns = [
                { data: 'job_type', name: 'job_type' },
                { data: 'services', name: 'services' },
                { data: 'budget', name: 'budget' },
                { data: 'name', name: 'name' },
                { data: 'purchased_date', name: 'purchased_date' },
            ];

            <?php if(Auth::user()->type === 0): ?>
                columns.push({ data: 'purchased_by', name: 'purchased_by' });
            <?php endif; ?>

            columns.push({ data: 'action', name: 'action', orderable: false, searchable: false });

            var table = $('#base-style').DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('transactions.data')); ?>",
                columns: columns,
                language: languageOptions[userLang] || languageOptions.en
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\NAHID\Desktop\fiverr\leadsApp\resources\views/transactions.blade.php ENDPATH**/ ?>