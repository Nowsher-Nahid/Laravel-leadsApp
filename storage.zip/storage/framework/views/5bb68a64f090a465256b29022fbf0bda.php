<?php echo e($slot); ?>

<?php /**PATH C:\Users\NAHID\Desktop\fiverr\leadsApp\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>