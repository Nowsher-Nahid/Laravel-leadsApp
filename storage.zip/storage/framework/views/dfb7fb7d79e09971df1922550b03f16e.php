
<?php $__env->startSection('title', __('messages.update_lead')); ?>
<?php $__env->startSection('content'); ?>

    <section class="pc-container">
        <div class="pc-content">
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('messages.dashboard')); ?></a></li>
                                <li class="breadcrumb-item" aria-current="page"><?php echo e(__('messages.leads')); ?></li>
                            </ul>
                        </div>
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h2 class="mb-0"><?php echo e(__('messages.update_lead')); ?></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5><?php echo e(__('messages.lead_form')); ?></h5>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('lead.update', $lead->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <h4 class="mb-4"><?php echo e(__('messages.project_info')); ?></h4>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="job-type"><?php echo e(__('messages.job_type')); ?></label>
                                            <select class="form-select" id="job-type" name="job_type" required>
                                                <option value=""><?php echo e(__('Select Type')); ?></option>
                                                <option value="Website laten maken" <?php echo e((old('job_type', $lead->job_type) == 'Website laten maken') ? 'selected' : ''); ?> ><?php echo e(__('messages.website_laten_maken')); ?></option>
                                                <option value="Webshop laten maken" <?php echo e((old('job_type', $lead->job_type) == 'Webshop laten maken') ? 'selected' : ''); ?> ><?php echo e(__('messages.webshop_laten_maken')); ?></option>
                                                <option value="Redesign bestaande website" <?php echo e((old('job_type', $lead->job_type) == 'Redesign bestaande website') ? 'selected' : ''); ?> ><?php echo e(__('messages.redesign_bestaande_website')); ?>Redesign bestaande website</option>
                                            </select>
                                            <?php if($errors->has('job_type')): ?>
                                                <div class="text-danger mt-2">
                                                    <?php echo e($errors->first('job_type')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="deadline"><?php echo e(__('messages.deadline')); ?></label>
                                            <input type="date" class="form-control" id="deadline" name="deadline" value="<?php echo e($lead->deadline); ?>" placeholder="Enter deadline" required>
                                            <?php if($errors->has('deadline')): ?>
                                                <div class="text-danger mt-2">
                                                    <?php echo e($errors->first('deadline')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="budget"><?php echo e(__('messages.budget')); ?></label>
                                            <select class="form-select" id="budget" name="budget" required>
                                                <option value="">Select Budget</option>
                                                <option value="Minder dan €1000" <?php echo e((old('budget', $lead->budget) == 'Minder dan €1000') ? 'selected' : ''); ?> ><?php echo e(__('messages.minder_dan_1000')); ?></option>
                                                <option value="€1000 - €2000" <?php echo e((old('budget', $lead->budget) == '€1000 - €2000') ? 'selected' : ''); ?> ><?php echo e(__('messages.1000_2000')); ?></option>
                                                <option value="Meer dan €2000" <?php echo e((old('budget', $lead->budget) == 'Meer dan €2000') ? 'selected' : ''); ?> ><?php echo e(__('messages.meer_dan_2000')); ?></option>
                                                <option value="Geen idee" <?php echo e((old('budget', $lead->budget) == 'Geen idee') ? 'selected' : ''); ?> ><?php echo e(__('messages.geen_idee')); ?></option>
                                            </select>
                                            <?php if($errors->has('budget')): ?>
                                                <div class="text-danger mt-2">
                                                    <?php echo e($errors->first('budget')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="price"><?php echo e(__('messages.price')); ?></label>
                                            <select class="form-select" id="price" name="price" required>
                                                <?php if($lead->price == 0.00): ?>
                                                    <option value="<?php echo e($settings->budget_price_1); ?>" <?php echo e((old('budget', $lead->budget) == 'Minder dan €1000') ? 'selected' : ''); ?> ><?php echo e($settings->budget_price_1); ?></option>
                                                    <option value="<?php echo e($settings->budget_price_2); ?>" <?php echo e((old('budget', $lead->budget) == '€1000 - €2000') ? 'selected' : ''); ?> ><?php echo e($settings->budget_price_2); ?></option>
                                                    <option value="<?php echo e($settings->budget_price_3); ?>" <?php echo e((old('budget', $lead->budget) == 'Meer dan €2000') ? 'selected' : ''); ?> ><?php echo e($settings->budget_price_3); ?></option>
                                                    <option value="<?php echo e($settings->budget_price_4); ?>" <?php echo e((old('budget', $lead->budget) == 'Geen idee') ? 'selected' : ''); ?> ><?php echo e($settings->budget_price_4); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($settings->budget_price_1); ?>" <?php echo e($lead->price == $settings->budget_price_1 ? 'selected' : ''); ?>>
                                                        <?php echo e($settings->budget_price_1); ?>

                                                    </option>
                                                    <option value="<?php echo e($settings->budget_price_2); ?>" <?php echo e($lead->price == $settings->budget_price_2 ? 'selected' : ''); ?>>
                                                        <?php echo e($settings->budget_price_2); ?>

                                                    </option>
                                                    <option value="<?php echo e($settings->budget_price_3); ?>" <?php echo e($lead->price == $settings->budget_price_3 ? 'selected' : ''); ?>>
                                                        <?php echo e($settings->budget_price_3); ?>

                                                    </option>
                                                    <option value="<?php echo e($settings->budget_price_4); ?>" <?php echo e($lead->price == $settings->budget_price_4 ? 'selected' : ''); ?>>
                                                        <?php echo e($settings->budget_price_4); ?>

                                                    </option>
                                                <?php endif; ?>
                                            </select>
                                            <?php if($errors->has('price')): ?>
                                                <div class="text-danger mt-2">
                                                    <?php echo e($errors->first('price')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="extra-services"><?php echo e(__('messages.extra_services')); ?></label>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" id="service-logo" name="services[]" value="Logo & Branding" 
                                                <?php echo e(is_array(old('services', json_decode($lead->services, true))) && in_array('Logo & Branding', old('services', json_decode($lead->services, true))) ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="service-logo"><?php echo e(__('messages.logo_branding')); ?></label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" id="service-seo" name="services[]" value="Google SEO" 
                                                <?php echo e(is_array(old('services', json_decode($lead->services, true))) && in_array('Google SEO', old('services', json_decode($lead->services, true))) ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="service-seo"><?php echo e(__('messages.google_seo')); ?></label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" id="service-writing" name="services[]" value="Copy Writing" 
                                                <?php echo e(is_array(old('services', json_decode($lead->services, true))) && in_array('Copy Writing', old('services', json_decode($lead->services, true))) ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="service-writing"><?php echo e(__('messages.copy_writing')); ?></label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" id="service-ads" name="services[]" value="Social Media Advertising" 
                                                <?php echo e(is_array(old('services', json_decode($lead->services, true))) && in_array('Social Media Advertising', old('services', json_decode($lead->services, true))) ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="service-ads"><?php echo e(__('messages.social_media_advertising')); ?></label>
                                            </div>
                                            <?php if($errors->has('services')): ?>
                                                <div class="text-danger mt-2">
                                                    <?php echo e($errors->first('services')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    
                                </div>
                                <h4 class="mb-4 mt-4"><?php echo e(__('messages.user_info')); ?></h4>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="name"><?php echo e(__('messages.name')); ?></label>
                                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($lead->name); ?>" placeholder="__('messages.enter_name')" required>
                                            <?php if($errors->has('name')): ?>
                                                <div class="text-danger mt-2">
                                                    <?php echo e($errors->first('name')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="phone"><?php echo e(__('messages.phone')); ?></label>
                                            <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e($lead->phone); ?>" placeholder="__('messages.enter_phone')" required>
                                            <?php if($errors->has('phone')): ?>
                                                <div class="text-danger mt-2">
                                                    <?php echo e($errors->first('phone')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="email"><?php echo e(__('messages.email')); ?></label>
                                            <input type="email" class="form-control" id="email" name="email" value="<?php echo e($lead->email); ?>" placeholder="__('messages.enter_email')" required>
                                            <?php if($errors->has('email')): ?>
                                                <div class="text-danger mt-2">
                                                    <?php echo e($errors->first('email')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="company"><?php echo e(__('messages.company')); ?></label>
                                            <input type="text" class="form-control" id="company" name="company" value="<?php echo e($lead->company); ?>" placeholder="__('messages.enter_company')" required>
                                            <?php if($errors->has('company')): ?>
                                                <div class="text-danger mt-2">
                                                    <?php echo e($errors->first('company')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="website-url"><?php echo e(__('messages.website')); ?></label>
                                            <input type="text" class="form-control" id="website-url" name="website_url" value="<?php echo e($lead->website_url); ?>" placeholder="__('messages.enter_website')" required>
                                            <?php if($errors->has('website_url')): ?>
                                                <div class="text-danger mt-2">
                                                    <?php echo e($errors->first('website_url')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="description"><?php echo e(__('messages.description')); ?></label>
                                            <textarea class="form-control" id="description" rows="5" name="description" required><?php echo e($lead->description); ?></textarea>
                                            <?php if($errors->has('description')): ?>
                                                <div class="text-danger mt-2">
                                                    <?php echo e($errors->first('description')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <h4 class="mb-4"><?php echo e(__('messages.lead_status')); ?></h4>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="status"><?php echo e(__('messages.status')); ?></label>
                                            <select class="form-select" id="status" name="status">
                                                <option value="0" <?php echo e((old('status', $lead->status) == '0') ? 'selected' : ''); ?>><?php echo e(__('messages.pending')); ?></option>
                                                <option value="1" <?php echo e((old('status', $lead->status) == '1') ? 'selected' : ''); ?>><?php echo e(__('messages.published')); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="sold_count"><?php echo e(__('messages.sold_status')); ?></label>
                                            <select class="form-select" id="sold_count" name="sold_count">
                                                <option value="0" <?php echo e((old('sold_count', $lead->sold_count) == '0') ? 'selected' : ''); ?>><?php echo e(__('messages.new')); ?></option>
                                                <?php for($i = 1; $i < $settings->max_sold; $i++): ?>
                                                    <option value="<?php echo e($i); ?>" <?php echo e((old('sold_count', $lead->sold_count) == $i) ? 'selected' : ''); ?>><?php echo e($i); ?> <?php echo e(__('messages.sold')); ?></option>
                                                <?php endfor; ?>
                                                <option value="Full" <?php echo e((old('sold_count', $lead->sold_count) == $settings->max_sold) ? 'selected' : ''); ?>><?php echo e(__('messages.full')); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary mb-4"><?php echo e(__('messages.update_lead')); ?></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\NAHID\Desktop\fiverr\leadsApp\resources\views/edit-lead.blade.php ENDPATH**/ ?>