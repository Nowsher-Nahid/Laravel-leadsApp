<?php $__env->startSection('title', __('messages.login')); ?>
<?php $__env->startSection('content'); ?>

<div class="auth-main">

    <div class="language">
        <a href="<?php echo e(url('locale/nl')); ?>" class="me-1 <?php echo e(app()->getLocale() === 'nl' ? 'text-bold' : ''); ?>">
            <?php echo e(__('messages.dutch')); ?>

        </a>
        |
        <a href="<?php echo e(url('locale/en')); ?>" class="ms-1 <?php echo e(app()->getLocale() === 'en' ? 'text-bold' : ''); ?>">
            <?php echo e(__('messages.english')); ?>

        </a>
    </div>

    <div class="auth-wrapper v1">
      <div class="auth-form">
        <div class="card my-5">
          <div class="card-body">

            <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
                <div class="text-center">
                    <a href="#"><img src="<?php echo e(asset('assets/images/logo-dark.svg')); ?>" alt="img" /></a>
                </div>
                <h4 class="text-center f-w-500 my-3"><?php echo e(__('messages.login_form')); ?></h4>
                <div class="mb-3">
                    <input type="email" class="form-control" id="email" name="email" placeholder="<?php echo e(__('messages.email_address')); ?>">
                    <?php if($errors->has('email')): ?>
						<div class="text-danger mt-2">
							<?php echo e($errors->first('email')); ?>

						</div>
					<?php endif; ?>
                </div>
                <div class="mb-3">
                    <input type="password" class="form-control" id="password" name="password" placeholder="<?php echo e(__('messages.password')); ?>">
                    <?php if($errors->has('password')): ?>
						<div class="text-danger mt-2">
							<?php echo e($errors->first('password')); ?>

						</div>
					<?php endif; ?>
                </div>
                <h6 class="text-secondary f-w-400 mb-0 text-end">
                    <a href="<?php echo e(route('password.request')); ?>"> <?php echo e(__('messages.forgot_password')); ?> </a>
                </h6>
                <div class="d-grid mt-4">
                    <button type="submit" class="btn btn-primary"><?php echo e(__('messages.login')); ?></button>
                </div>
                <div class="d-flex justify-content-between align-items-end mt-4">
                    <h6 class="f-w-500 mb-0"><?php echo e(__("messages.no_account")); ?></h6>
                    <a href="<?php echo e(route('register')); ?>" class="link-primary"><?php echo e(__('messages.create_account')); ?></a>
                </div>
            </form>

          </div>
        </div>
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\NAHID\Desktop\fiverr\leadsApp\resources\views/auth/login.blade.php ENDPATH**/ ?>