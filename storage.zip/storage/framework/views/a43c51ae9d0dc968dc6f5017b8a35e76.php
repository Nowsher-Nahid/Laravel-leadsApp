<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\NAHID\Desktop\fiverr\leadsApp\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>