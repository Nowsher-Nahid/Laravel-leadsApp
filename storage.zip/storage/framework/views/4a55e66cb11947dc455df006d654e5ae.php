
<?php $__env->startSection('title', 'Lead Details'); ?>
<?php $__env->startSection('content'); ?>

<section class="pc-container">
  <div class="pc-content">
      <div class="page-header">
          <div class="page-block">
              <div class="row align-items-center">
                  <div class="col-md-12">
                      <ul class="breadcrumb">
                          <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('messages.dashboard')); ?></a></li>
                          <li class="breadcrumb-item" aria-current="page"><?php echo e(__('messages.leads')); ?></li>
                      </ul>
                  </div>
                  <div class="col-md-12">
                      <div class="page-header-title">
                          <h2 class="mb-0"><?php echo e(__('messages.lead_details')); ?></h2>
                      </div>
                  </div>
              </div>
          </div>
      </div>

      <div class="row">
          <div class="col-md-12">
              <div class="card">
                  <div class="card-header">
                      <h5><?php echo e(__('messages.primary_details')); ?></h5>
                  </div>
                  <div class="card-body">
                      <ul class="list-group list-group-flush">
                          <li class="list-group-item px-0 pt-0">
                              <div class="row">
                                  <div class="col-md-6">
                                      <p class="mb-1 text-muted"><?php echo e(__('messages.job_type')); ?></p>
                                      <p class="mb-0"><?php echo e($lead->job_type); ?></p>
                                  </div>
                                  <div class="col-md-6">
                                      <p class="mb-1 text-muted"><?php echo e(__('messages.extra_services')); ?></p>
                                      <p class="mb-0">
                                          <?php
                                              $servicesArray = json_decode($lead->services, true);
                                          ?>
                                          <?php if(is_array($servicesArray)): ?>
                                              <?php echo e(implode(', ', $servicesArray)); ?>

                                          <?php else: ?>
                                              <?php echo e(__('messages.no_extra_services_selected')); ?>

                                          <?php endif; ?>
                                      </p>
                                  </div>
                              </div>
                          </li>
                          <li class="list-group-item px-0">
                              <div class="row">
                                  <div class="col-md-6">
                                      <p class="mb-1 text-muted"><?php echo e(__('messages.budget')); ?></p>
                                      <p class="mb-0"><?php echo e($lead->budget); ?></p>
                                  </div>
                                  <div class="col-md-6">
                                      <p class="mb-1 text-muted"><?php echo e(__('messages.deadline')); ?></p>
                                      <p class="mb-0"><?php echo e($lead->deadline); ?></p>
                                  </div>
                              </div>
                          </li>
                          <li class="list-group-item px-0 pb-0">
                              <p class="mb-1 text-muted"><?php echo e(__('messages.description')); ?></p>
                              <p class="mb-0"><?php echo e($lead->description); ?></p>
                          </li>
                      </ul>
                  </div>
              </div>

              <?php if(($userHasPurchased && Auth::user()->type === 1) || Auth::user()->type === 0): ?>
                  <div class="card">
                      <div class="card-header">
                          <h5><?php echo e(__('messages.contact_details')); ?></h5>
                      </div>
                      <div class="card-body">
                          <ul class="list-group list-group-flush">
                              <li class="list-group-item px-0 pt-0">
                                  <div class="row">
                                      <div class="col-md-6">
                                          <p class="mb-1 text-muted"><?php echo e(__('messages.name')); ?></p>
                                          <p class="mb-0"><?php echo e($lead->name); ?></p>
                                      </div>
                                      <div class="col-md-6">
                                          <p class="mb-1 text-muted"><?php echo e(__('messages.phone')); ?></p>
                                          <p class="mb-0"><?php echo e($lead->phone); ?></p>
                                      </div>
                                  </div>
                              </li>
                              <li class="list-group-item px-0">
                                  <div class="row">
                                      <div class="col-md-6">
                                          <p class="mb-1 text-muted"><?php echo e(__('messages.email')); ?></p>
                                          <p class="mb-0"><?php echo e($lead->email); ?></p>
                                      </div>
                                      <div class="col-md-6">
                                          <p class="mb-1 text-muted"><?php echo e(__('messages.company_name')); ?></p>
                                          <p class="mb-0"><?php echo e($lead->company); ?></p>
                                      </div>
                                  </div>
                              </li>
                              <li class="list-group-item px-0 pb-0">
                                  <div class="row">
                                      <div class="col-md-6">
                                          <p class="mb-1 text-muted"><?php echo e(__('messages.website_url')); ?></p>
                                          <p class="mb-0"><?php echo e($lead->website_url); ?></p>
                                      </div>
                                  </div>
                              </li>
                          </ul>
                      </div>
                  </div>
              <?php endif; ?>

          </div>
      </div>

      <?php if(Auth::user()->type === 1): ?>
          <?php if($isSoldOut): ?>
              <div class="row">
                  <div class="col-md-4"></div>
                  <div class="col-md-4">
                      <div class="alert alert-warning mb-4 text-center"><?php echo e(__('messages.lead_sold_out')); ?></div>
                  </div>
                  <div class="col-md-4"></div>
              </div>
          <?php elseif(!$userHasPurchased): ?>
              <div class="text-end">
                  <button type="button" class="btn btn-primary mb-4" data-bs-toggle="modal" data-bs-target="#paymentModal"><?php echo e(__('messages.buy_now')); ?></button>
              </div>
          <?php else: ?>
              <div class="row">
                  <div class="col-md-4"></div>
                  <div class="col-md-4">
                      <div class="alert alert-success mb-4 text-center"><?php echo e(__('messages.already_purchased_lead')); ?></div>
                  </div>
                  <div class="col-md-4"></div>
              </div>
          <?php endif; ?>
      <?php endif; ?>

  </div>
</section>


    <!-- Modal -->
    <div class="modal fade" id="paymentModal" tabindex="-1" aria-labelledby="paymentModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="paymentModalLabel"><?php echo e(__('messages.enter_card_details')); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="payment-form" action="<?php echo e(route('leads.buy', $lead->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div id="card-element" class="my-3">
                            <!-- Stripe Card Element will be inserted here. -->
                        </div>
                        <div id="card-errors" role="alert" class="text-danger my-2"></div>
                        <button id="submit-button" class="btn btn-success w-100"><?php echo e(__('messages.submit_payment')); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>

  <?php $__env->stopSection(); ?>

  <?php $__env->startPush('scripts'); ?>
  <script>
    // Initialize Stripe
    var stripe = Stripe('<?php echo e(config('services.stripe.key')); ?>');
    var elements = stripe.elements();

    // Create an instance of the card Element
    var card = elements.create('card');
    card.mount('#card-element');

    // Handle form submission
    var form = document.getElementById('payment-form');
    form.addEventListener('submit', function(event) {
        event.preventDefault();

        stripe.createToken(card).then(function(result) {
            if (result.error) {
                // Inform the user if there was an error
                console.error(result.error.message);
            } else {
                // Send the token to your server
                var hiddenInput = document.createElement('input');
                hiddenInput.setAttribute('type', 'hidden');
                hiddenInput.setAttribute('name', 'stripeToken');
                hiddenInput.setAttribute('value', result.token.id);
                form.appendChild(hiddenInput);

                // Submit the form
                form.submit();
            }
        });
    });
</script>
  <?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\NAHID\Desktop\fiverr\leadsApp\resources\views/lead-details.blade.php ENDPATH**/ ?>