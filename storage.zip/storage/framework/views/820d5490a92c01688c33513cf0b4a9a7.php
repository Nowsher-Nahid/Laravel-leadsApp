<?php $__env->startSection('title', __('messages.register')); ?>
<?php $__env->startSection('content'); ?>

<div class="auth-main">

    <div class="language">
        <a href="<?php echo e(url('locale/nl')); ?>" class="me-1 <?php echo e(app()->getLocale() === 'nl' ? 'text-bold' : ''); ?>">
            <?php echo e(__('messages.dutch')); ?>

        </a>
        |
        <a href="<?php echo e(url('locale/en')); ?>" class="ms-1 <?php echo e(app()->getLocale() === 'en' ? 'text-bold' : ''); ?>">
            <?php echo e(__('messages.english')); ?>

        </a>
    </div>

    <div class="auth-wrapper v1">
        <div class="auth-form">
          <div class="card my-5">
            <div class="card-body">
      
              <form method="POST" action="<?php echo e(route('register')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="text-center">
                  <a href="#"><img src="<?php echo e(asset('assets/images/logo-dark.svg')); ?>" alt="img"></a>
                </div>
                <h4 class="text-center f-w-500 my-3"><?php echo e(__('messages.register_form')); ?></h4>
                
                <div class="mb-3">
                  <input type="text" class="form-control" name="first_name" placeholder="<?php echo e(__('messages.first_name')); ?>" value="<?php echo e(old('first_name')); ?>" required>
                  <?php if($errors->has('first_name')): ?>
                    <div class="text-danger mt-2">
                      <?php echo e($errors->first('first_name')); ?>

                    </div>
                  <?php endif; ?>
                </div>
                
                <div class="mb-3">
                  <input type="text" class="form-control" name="last_name" placeholder="<?php echo e(__('messages.last_name')); ?>" value="<?php echo e(old('last_name')); ?>" required>
                  <?php if($errors->has('last_name')): ?>
                    <div class="text-danger mt-2">
                      <?php echo e($errors->first('last_name')); ?>

                    </div>
                  <?php endif; ?>
                </div>
                
                <div class="mb-3">
                  <input type="email" class="form-control" name="email" placeholder="<?php echo e(__('messages.email_address')); ?>" value="<?php echo e(old('email')); ?>" required>
                  <?php if($errors->has('email')): ?>
                    <div class="text-danger mt-2">
                      <?php echo e($errors->first('email')); ?>

                    </div>
                  <?php endif; ?>
                </div>
                
                <div class="mb-3">
                  <input type="text" class="form-control" name="phone" placeholder="<?php echo e(__('messages.phone_number')); ?>" value="<?php echo e(old('phone')); ?>" required>
                  <?php if($errors->has('phone')): ?>
                    <div class="text-danger mt-2">
                      <?php echo e($errors->first('phone')); ?>

                    </div>
                  <?php endif; ?>
                </div>
                
                <div class="mb-3">
                  <input type="password" class="form-control" id="password" name="password" placeholder="<?php echo e(__('messages.password')); ?>" required>
                </div>
                
                <div class="mb-3">
                  <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" placeholder="<?php echo e(__('messages.confirm_password')); ?>" required>
                  <?php if($errors->has('password')): ?>
                    <div class="text-danger mt-2">
                      <?php echo e($errors->first('password')); ?>

                    </div>
                  <?php endif; ?>
                </div>
                
                <div class="mb-3">
                  <input type="text" class="form-control" name="company_name" placeholder="<?php echo e(__('messages.company_name')); ?>" value="<?php echo e(old('company_name')); ?>">
                  <?php if($errors->has('company_name')): ?>
                    <div class="text-danger mt-2">
                      <?php echo e($errors->first('company_name')); ?>

                    </div>
                  <?php endif; ?>
                </div>
                
                <div class="mb-3">
                  <input type="text" class="form-control" name="company_vat" placeholder="<?php echo e(__('messages.company_vat')); ?>" value="<?php echo e(old('company_vat')); ?>">
                  <?php if($errors->has('company_vat')): ?>
                    <div class="text-danger mt-2">
                      <?php echo e($errors->first('company_vat')); ?>

                    </div>
                  <?php endif; ?>
                </div>
                
                <div class="mb-3">
                  <label for=""><?php echo e(__('messages.profile_picture')); ?></label>
                  <input type="file" class="form-control mt-1" name="profile_picture" accept="image/*">
                  <?php if($errors->has('profile_picture')): ?>
                    <div class="text-danger mt-2">
                      <?php echo e($errors->first('profile_picture')); ?>

                    </div>
                  <?php endif; ?>
                </div>
                
                <div class="d-grid mt-4">
                  <button type="submit" class="btn btn-primary"><?php echo e(__('messages.sign_up')); ?></button>
                </div>
                
                <div class="d-flex justify-content-between align-items-end mt-4">
                  <h6 class="f-w-500 mb-0"><?php echo e(__('messages.already_have_account')); ?></h6>
                  <a href="<?php echo e(route('login')); ?>" class="link-primary"><?php echo e(__('messages.login_here')); ?></a>
                </div>
              </form>            
      
            </div>
          </div>
        </div>
      </div>
      
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\NAHID\Desktop\fiverr\leadsApp\resources\views/auth/register.blade.php ENDPATH**/ ?>