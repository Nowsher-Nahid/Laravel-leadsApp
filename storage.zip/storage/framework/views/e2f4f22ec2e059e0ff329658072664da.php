<?php echo e($slot); ?>

<?php /**PATH C:\Users\NAHID\Desktop\fiverr\leadsApp\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>