<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\NAHID\Desktop\fiverr\leadsApp\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>