
<?php $__env->startSection('title', __('messages.update_partner_info')); ?>
<?php $__env->startSection('content'); ?>

    <section class="pc-container">
        <div class="pc-content">
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('messages.dashboard')); ?></a></li>
                                <li class="breadcrumb-item" aria-current="page"><?php echo e(__('messages.partners')); ?></li>
                            </ul>
                        </div>
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h2 class="mb-0"><?php echo e(__('messages.update_partner')); ?></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5><?php echo e(__('messages.lead_form')); ?></h5>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('user.update', $user->id)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="mb-3 text-center">
                                            <img class="img-fluid" src="<?php echo e(asset($user->profile_picture)); ?>" alt="<?php echo e(__('messages.profile_picture')); ?>" width="100">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="first_name"><?php echo e(__('messages.first_name')); ?></label>
                                            <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo e($user->first_name); ?>" placeholder="<?php echo e(__('messages.enter_first_name')); ?>" required>
                                            <?php if($errors->has('first_name')): ?>
                                                <div class="text-danger mt-2">
                                                    <?php echo e($errors->first('first_name')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="last_name"><?php echo e(__('messages.last_name')); ?></label>
                                            <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo e($user->last_name); ?>" placeholder="<?php echo e(__('messages.enter_last_name')); ?>" required>
                                            <?php if($errors->has('last_name')): ?>
                                                <div class="text-danger mt-2">
                                                    <?php echo e($errors->first('last_name')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="email"><?php echo e(__('messages.email')); ?></label>
                                            <input type="email" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>" placeholder="<?php echo e(__('messages.enter_email')); ?>" required>
                                            <?php if($errors->has('email')): ?>
                                                <div class="text-danger mt-2">
                                                    <?php echo e($errors->first('email')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="phone"><?php echo e(__('messages.phone')); ?></label>
                                            <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e($user->phone); ?>" placeholder="<?php echo e(__('messages.enter_phone')); ?>" required>
                                            <?php if($errors->has('phone')): ?>
                                                <div class="text-danger mt-2">
                                                    <?php echo e($errors->first('phone')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="company_name"><?php echo e(__('messages.company_name')); ?></label>
                                            <input type="text" class="form-control" id="company_name" name="company_name" value="<?php echo e($user->company_name); ?>" placeholder="<?php echo e(__('messages.enter_company_name')); ?>" required>
                                            <?php if($errors->has('company_name')): ?>
                                                <div class="text-danger mt-2">
                                                    <?php echo e($errors->first('company_name')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label" for="company_vat"><?php echo e(__('messages.company_vat')); ?></label>
                                            <input type="text" class="form-control" id="company_vat" name="company_vat" value="<?php echo e($user->company_vat); ?>" placeholder="<?php echo e(__('messages.enter_company_vat')); ?>" required>
                                            <?php if($errors->has('company_vat')): ?>
                                                <div class="text-danger mt-2">
                                                    <?php echo e($errors->first('company_vat')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for=""><?php echo e(__('messages.profile_picture')); ?></label>
                                            <input type="file" class="form-control mt-1" name="profile_picture" accept="image/*">
                                            <?php if($errors->has('profile_picture')): ?>
                                                <div class="text-danger mt-2">
                                                    <?php echo e($errors->first('profile_picture')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-end">
                                    <button type="submit" class="btn btn-primary mb-4"><?php echo e(__('messages.update_partner')); ?></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            

        </div>
    </section>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\NAHID\Desktop\fiverr\leadsApp\resources\views/edit-user.blade.php ENDPATH**/ ?>