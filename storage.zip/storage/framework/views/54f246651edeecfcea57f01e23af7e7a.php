<!DOCTYPE html>
<html>
<head>
    <title><?php echo e(__('messages.lead_published.title')); ?></title>
</head>
<body>
    <p><?php echo e(__('messages.lead_published.greeting')); ?></p>
    <p><?php echo e(__('messages.lead_published.intro')); ?></p>
    <p><strong><?php echo e(__('messages.lead_published.job_type')); ?></strong> <?php echo e($lead->job_type); ?></p>
    <p><strong><?php echo e(__('messages.lead_published.budget')); ?></strong> <?php echo e($lead->budget); ?></p>
    <p><strong><?php echo e(__('messages.lead_published.price')); ?></strong> €<?php echo e($lead->price); ?></p>
    <p><?php echo e(__('messages.lead_published.outro')); ?></p>
    <p><?php echo e(__('messages.lead_published.regards')); ?><br><?php echo e(__('messages.lead_published.team')); ?></p>
</body>
</html>
<?php /**PATH C:\Users\NAHID\Desktop\fiverr\leadsApp\resources\views/emails/lead_published.blade.php ENDPATH**/ ?>