<!doctype html>
<html lang="en">

  <head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link rel="icon" href="<?php echo e(asset('assets/images/favicon.svg')); ?>" type="image/x-icon" />
    <!-- data tables css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins/dataTables.bootstrap5.min.css')); ?>" />
    <!-- [Font] Family -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/inter/inter.css')); ?>" id="main-font-link" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/phosphor/duotone/style.css')); ?>" />
    <!-- [Tabler Icons] https://tablericons.com -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/tabler-icons.min.css')); ?>" />
    <!-- [Feather Icons] https://feathericons.com -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/feather.css')); ?>" />
    <!-- [Font Awesome Icons] https://fontawesome.com/icons -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/fontawesome.css')); ?>" />
    <!-- [Material Icons] https://fonts.google.com/icons -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/material.css')); ?>" />
    <!-- [Template CSS Files] -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" id="main-style-link" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style-preset.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>" />
  </head>

  <body data-pc-preset="preset-1" data-pc-sidebar-caption="true" data-pc-layout="vertical" data-pc-direction="ltr" data-pc-theme_contrast="" data-pc-theme="light">

    <div class="page-loader">
        <div class="bar"></div>
    </div>

    <?php if(!Route::is('login') && !Route::is('register')): ?>

        <nav class="pc-sidebar">
            <div class="navbar-wrapper">
                <div class="m-header">
                <a href="<?php echo e(route('dashboard')); ?>" class="b-brand text-primary">
                    <img src="<?php echo e(asset('assets/images/logo-dark.svg')); ?>" class="img-fluid logo-lg" alt="logo" />
                </a>
                </div>
                <div class="navbar-content">
                <div class="card pc-user-card">
                    <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                            <img src="<?php echo e(file_exists(public_path(Auth::user()->profile_picture)) && Auth::user()->profile_picture ? asset(Auth::user()->profile_picture) : asset('assets/images/profile-pictures/placeholder.png')); ?>" alt="user-image" class="user-avtar wid-45 rounded-circle">
                            
                        </div>
                        <div class="flex-grow-1 ms-3 me-2">
                        <h6 class="mb-0"><?php echo e(Auth::user()->first_name); ?></h6>
                        <small>
                            <?php if(Auth::user()->type == 1): ?>
                                <?php echo e(__('messages.user')); ?>

                            <?php else: ?>
                                <?php echo e(__('messages.administrator')); ?>

                            <?php endif; ?>
                        </small>
                        </div>
                        <a class="btn btn-icon btn-link-secondary avtar" data-bs-toggle="collapse" href="#pc_sidebar_userlink">
                        <svg class="pc-icon">
                            <use xlink:href="#custom-sort-outline"></use>
                        </svg>
                        </a>
                    </div>
                    <div class="collapse pc-user-links" id="pc_sidebar_userlink">
                        <div class="pt-3">
                            <a href="<?php echo e(route('profile.edit')); ?>">
                                <i class="ti ti-user"></i>
                                <span><?php echo e(__('messages.my_account')); ?></span>
                            </a>

                            <?php if(Auth::user()->type === 0): ?>
                                <a href="<?php echo e(route('settings')); ?>">
                                    <i class="ti ti-settings"></i>
                                    <span><?php echo e(__('messages.settings')); ?></span>
                                </a>
                            <?php endif; ?>

                            <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <i class="ti ti-power"></i>
                                <span><?php echo e(__('messages.logout')); ?></span>
                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </div>
                    </div>
                </div>

                <ul class="pc-navbar">
                    <li class="pc-item pc-caption">
                        <label><?php echo e(__('messages.navigation')); ?></label>
                    </li>
                    <?php if(Auth::user()->type === 0): ?>
                    <li class="pc-item">
                        <a href="<?php echo e(route('dashboard')); ?>" class="pc-link">
                            <span class="pc-micon">
                                <svg class="pc-icon">
                                    <use xlink:href="#custom-status-up"></use>
                                </svg>
                            </span>
                            <span class="pc-mtext"><?php echo e(__('messages.dashboard')); ?></span>
                        </a>
                    </li>
                    <?php endif; ?>
                    <li class="pc-item">
                        <a href="<?php echo e(route('lead.index')); ?>" class="pc-link">
                            <span class="pc-micon">
                                <svg class="pc-icon">
                                    <use xlink:href="#custom-keyboard"></use>
                                </svg>
                            </span>
                            <span class="pc-mtext"><?php echo e(__('messages.leads')); ?></span>
                        </a>
                    </li>
                    <?php if(Auth::user()->type === 0): ?>
                    <li class="pc-item">
                        <a href="<?php echo e(route('user.index')); ?>" class="pc-link">
                            <span class="pc-micon">
                                <svg class="pc-icon">
                                    <use xlink:href="#custom-profile-2user-outline"></use>
                                </svg>
                            </span>
                            <span class="pc-mtext"><?php echo e(__('messages.partners')); ?></span>
                        </a>
                    </li>
                    <li class="pc-item">
                        <a href="<?php echo e(route('settings')); ?>" class="pc-link">
                            <span class="pc-micon">
                                <svg class="pc-icon">
                                    <use xlink:href="#custom-setting-2"></use>
                                </svg>
                            </span>
                            <span class="pc-mtext"><?php echo e(__('messages.settings')); ?></span>
                        </a>
                    </li>
                    <?php endif; ?>
                    <li class="pc-item">
                        <a href="<?php echo e(route('transactions.index')); ?>" class="pc-link">
                            <span class="pc-micon">
                                <svg class="pc-icon">
                                    <use xlink:href="#custom-text-align-justify-center"></use>
                                </svg>
                            </span>
                            <span class="pc-mtext"><?php echo e(__('messages.transactions')); ?></span>
                        </a>
                    </li>
                </ul>
                </div>
            </div>
        </nav>

        <header class="pc-header">
            <div class="header-wrapper">
                <div class="me-auto pc-mob-drp">
                <ul class="list-unstyled">
                    <li class="pc-h-item pc-sidebar-collapse">
                    <a href="#" class="pc-head-link ms-0" id="sidebar-hide">
                        <i class="ti ti-menu-2"></i>
                    </a>
                    </li>
                    <li class="pc-h-item pc-sidebar-popup">
                    <a href="#" class="pc-head-link ms-0" id="mobile-collapse">
                        <i class="ti ti-menu-2"></i>
                    </a>
                    </li>
                </ul>
                </div>
                <div class="ms-auto">
                    <ul class="list-unstyled">
                        <li class="dropdown pc-h-item me-3">
                            <a href="<?php echo e(url('locale/nl')); ?>" class="me-1 <?php echo e(app()->getLocale() === 'nl' ? 'text-bold' : ''); ?>">
                                <?php echo e(__('messages.dutch')); ?>

                            </a>
                            |
                            <a href="<?php echo e(url('locale/en')); ?>" class="ms-1 <?php echo e(app()->getLocale() === 'en' ? 'text-bold' : ''); ?>">
                                <?php echo e(__('messages.english')); ?>

                            </a>
                        </li>
                        <li class="dropdown pc-h-item">
                            <div class="dropdown-menu dropdown-menu-end pc-h-dropdown">
                                <a href="<?php echo e(route('profile.edit')); ?>" class="dropdown-item">
                                    <i class="ti ti-user"></i>
                                    <span><?php echo e(__('messages.my_account')); ?></span>
                                </a>
                                <?php if(Auth::user()->type === 0): ?>
                                    <a href="<?php echo e(route('settings')); ?>" class="dropdown-item">
                                        <i class="ti ti-settings"></i>
                                        <span><?php echo e(__('messages.settings')); ?></span>
                                    </a>
                                <?php endif; ?>

                                <a href="<?php echo e(route('logout')); ?>" class="dropdown-item" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                    <i class="ti ti-power"></i>
                                    <span><?php echo e(__('messages.logout')); ?></span>
                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>

                                
                            </div>
                        </li>
                        <li class="dropdown pc-h-item header-user-profile">
                        <a
                            class="pc-head-link dropdown-toggle arrow-none me-0"
                            data-bs-toggle="dropdown"
                            href="#"
                            role="button"
                            aria-haspopup="false"
                            data-bs-auto-close="outside"
                            aria-expanded="false"
                        >
                            <img src="<?php echo e(file_exists(public_path(Auth::user()->profile_picture)) && Auth::user()->profile_picture ? asset(Auth::user()->profile_picture) : asset('assets/images/profile-pictures/placeholder.png')); ?>" alt="user-image" class="user-avtar">
                        </a>
                        <div class="dropdown-menu dropdown-user-profile dropdown-menu-end pc-h-dropdown">
                            <div class="dropdown-header d-flex align-items-center justify-content-between">
                            <h5 class="m-0"><?php echo e(__('messages.profile')); ?></h5>
                            </div>
                            <div class="dropdown-body">
                            <div class="profile-notification-scroll position-relative" style="max-height: calc(100vh - 225px)">
                                <div class="d-flex mb-1">
                                <div class="flex-shrink-0">
                                    <img src="<?php echo e(file_exists(public_path(Auth::user()->profile_picture)) && Auth::user()->profile_picture ? asset(Auth::user()->profile_picture) : asset('assets/images/profile-pictures/placeholder.png')); ?>" alt="user-image" class="user-avtar wid-35">
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h6 class="mb-1"><?php echo e(Auth::user()->first_name); ?> <?php echo e(Auth::user()->last_name); ?> 🖖</h6>
                                    <span><?php echo e(Auth::user()->email); ?></span>
                                </div>
                                </div>
                                <hr class="border-secondary border-opacity-50" />
                                <a href="<?php echo e(route('profile.edit')); ?>" class="dropdown-item">
                                    <span>
                                        <i class="ti ti-user"></i>
                                        <span><?php echo e(__('messages.my_account')); ?></span>
                                    </span>
                                </a>

                                <?php if(Auth::user()->type === 0): ?>
                                    <a href="<?php echo e(route('settings')); ?>" class="dropdown-item">
                                        <span>
                                            <svg class="pc-icon text-muted me-2">
                                            <use xlink:href="#custom-setting-outline"></use>
                                            </svg>
                                            <span><?php echo e(__('messages.settings')); ?></span>
                                        </span>
                                    </a>
                                <?php endif; ?>

                                <hr class="border-secondary border-opacity-50" />
                                <div class="d-grid mb-3">
                                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-primary w-100" onclick="event.preventDefault();
                                                this.closest('form').submit();">
                                            <svg class="pc-icon me-2">
                                            <use xlink:href="#custom-logout-1-outline"></use></svg><?php echo e(__('messages.logout')); ?>

                                        </button>
                                    </form>
                                </div>
                            </div>
                            </div>
                        </div>
                        </li>
                    </ul>
                </div>
            </div>
        </header>

    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>

    <footer class="pc-footer">
      <div class="footer-wrapper container-fluid">
        <div class="row">
          <div class="col my-1">
            <p class="m-0"
              >Able Pro &#9829; crafted by Team <a href="https://themeforest.net/user/phoenixcoded" target="_blank">Phoenixcoded</a></p
            >
          </div>
          <div class="col-auto my-1">
            <ul class="list-inline footer-link mb-0">
              <li class="list-inline-item"><a href="../index.html">Home</a></li>
              <li class="list-inline-item"><a href="https://phoenixcoded.gitbook.io/able-pro/" target="_blank">Documentation</a></li>
              <li class="list-inline-item"><a href="https://phoenixcoded.authordesk.app/" target="_blank">Support</a></li>
            </ul>
          </div>
        </div>
      </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="<?php echo e(asset('assets/js/plugins/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/simplebar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/fonts/custom-font.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/pcoded.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/feather.min.js')); ?>"></script>
    <!-- datatable Js -->
    <script src="<?php echo e(asset('assets/js/plugins/dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/dataTables.bootstrap5.min.js')); ?>"></script>
    <!-- Sweet Alert -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <script src="https://js.stripe.com/v3/"></script>
    
    <script>
        <?php if(session('success')): ?>
          Swal.fire({
            title: '<?php echo e(__('messages.success')); ?>',
            text: "<?php echo e(session('success')); ?>",
            icon: 'success',
            confirmButtonText: 'Ok'
          })
        <?php endif; ?>
        
        // Set userLang dynamically based on Laravel's locale
        const userLang = '<?php echo e(app()->getLocale()); ?>';

        // Define DataTable language options with translation keys
        const languageOptions = {
            en: <?php echo json_encode(__('messages.datatables', [], 'en')) ?>,
            nl: <?php echo json_encode(__('messages.datatables', [], 'nl')) ?>
        };

    </script>

    <?php echo $__env->yieldPushContent('scripts'); ?>

  </body>
</html>
<?php /**PATH C:\Users\NAHID\Desktop\fiverr\leadsApp\resources\views/layouts/main.blade.php ENDPATH**/ ?>