
<?php $__env->startSection('title', __('messages.user_list')); ?>
<?php $__env->startSection('content'); ?>

  <section class="pc-container">
    <div class="pc-content">
        <div class="page-header">
          <div class="page-block">
            <div class="row align-items-center">
              <div class="col-md-12">
                <ul class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                  <li class="breadcrumb-item" aria-current="page">Partners</li>
                </ul>
              </div>
              <div class="col-md-12">
                <div class="page-header-title">
                  <h2 class="mb-0">Partner List</h2>
                </div>
              </div>
            </div>
          </div>
        </div>

      <div class="row">
        <div class="col-sm-12">
          <div class="card">
            <div class="card-body">
              <div class="dt-responsive table-responsive">
                <table id="base-style" class="table table-striped table-bordered nowrap user-table">
                    <thead>
                        <tr>
                            <th><?php echo e(__('messages.sn')); ?></th>
                            <th><?php echo e(__('messages.name')); ?></th>
                            <th><?php echo e(__('messages.email')); ?></th>
                            <th><?php echo e(__('messages.phone')); ?></th>
                            <th><?php echo e(__('messages.company_name')); ?></th>
                            <th><?php echo e(__('messages.company_vat')); ?></th>
                            <th><?php echo e(__('messages.actions')); ?></th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(function () {
          var columns = [
              { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false },
              { data: 'full_name', name: 'full_name' },
              { data: 'email', name: 'email' },
              { data: 'phone', name: 'phone' },
              { data: 'company_name', name: 'company_name' },
              { data: 'company_vat', name: 'company_vat' },
              { data: 'action', name: 'action', orderable: false, searchable: false }
          ];

          var table = $('#base-style').DataTable({
              processing: true,
              serverSide: true,
              ajax: "<?php echo e(route('user.index')); ?>",
              columns: columns,
              language: languageOptions[userLang] || languageOptions.en
          });
      });

        // delete
        $(document).ready(function() {
            $('body').on('click', '.delete', function() {
                var id = $(this).data('id');
                Swal.fire({
                    title: '<?php echo e(__('messages.are_you_sure')); ?>',
                    text: "<?php echo e(__('messages.no_revert')); ?>",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: '<?php echo e(__('messages.yes_delete')); ?>'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: '/delete-user/' + id,
                            type: 'DELETE',
                            data: {
                                _token: '<?php echo e(csrf_token()); ?>',
                            },
                            success: function(response) {
                                if (response.success) {
                                    Swal.fire(
                                        '<?php echo e(__('messages.deleted')); ?>',
                                        '<?php echo e(__('messages.user_deleted')); ?>',
                                        'success'
                                    ).then(() => {
                                        window.location.reload();
                                    });
                                }
                            }
                        });
                    }
                });
            });
        });

    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\NAHID\Desktop\fiverr\leadsApp\resources\views/user-list.blade.php ENDPATH**/ ?>